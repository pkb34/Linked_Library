import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** Tests for Book: one normal and one bad-input case per public method. */
public class BookTest {
    private Book hobbit;

    @Before
    public void setUp() {
        hobbit = new Book("The Hobbit", "Tolkien", "FIC TOL", 1);
    }

    @Test
    public void constructorTrimsText() {
        Book b = new Book("  Dune ", " Herbert", "FIC HER ", 2);
        assertEquals("Dune", b.getTitle());
        assertEquals("Herbert", b.getAuthor());
        assertEquals("FIC HER", b.getCallNumber());
        assertEquals(2, b.getCopyId());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBlankTitle() {
        new Book("   ", "Tolkien", "FIC TOL", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullAuthor() {
        new Book("The Hobbit", null, "FIC TOL", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsZeroCopyId() {
        new Book("The Hobbit", "Tolkien", "FIC TOL", 0);
    }

    @Test
    public void isBlank() {
        assertTrue(Book.isBlank(null));
        assertTrue(Book.isBlank(" \t "));
        assertFalse(Book.isBlank("x"));
    }

    @Test
    public void matchesTitleOrAuthorIgnoringCase() {
        assertTrue(hobbit.matches("hob"));
        assertTrue(hobbit.matches("TOLK"));
        assertFalse(hobbit.matches("Dune"));
    }

    @Test
    public void matchesRejectsNullAndBlank() {
        assertFalse(hobbit.matches(null));
        assertFalse(hobbit.matches("   "));
    }

    @Test
    public void equalsUsesCopyIdOnly() {
        Book sameCopy = new Book("Other", "Other", "X", 1);
        Book secondCopy = new Book("The Hobbit", "Tolkien", "FIC TOL", 2);
        assertEquals(hobbit, sameCopy);
        assertEquals(hobbit.hashCode(), sameCopy.hashCode());
        assertNotEquals(hobbit, secondCopy);
    }

    @Test
    public void equalsRejectsNullAndOtherTypes() {
        assertFalse(hobbit.equals(null));
        assertFalse(hobbit.equals("The Hobbit"));
    }

    @Test
    public void toStringShowsCopyAndTitle() {
        assertEquals("#1 The Hobbit by Tolkien (FIC TOL)", hobbit.toString());
    }

    @Test
    public void specialCharactersStoredAsIs() {
        Book b = new Book("Quotes \"and\", commas", "O'Brien", "Z 9", 3);
        assertEquals("Quotes \"and\", commas", b.getTitle());
        assertTrue(b.matches("o'brien"));
    }

    @Test
    public void comparatorsOrderByFieldThenCopyId() {
        Book a = new Book("alpha", "Zed", "B", 5);
        Book z = new Book("Zeta", "adams", "A", 4);
        assertTrue(Book.BY_TITLE.compare(a, z) < 0);
        assertTrue(Book.BY_AUTHOR.compare(z, a) < 0);
        assertTrue(Book.BY_CALL_NUMBER.compare(z, a) < 0);
        assertTrue(Book.BY_COPY_ID.compare(z, a) < 0);
        Book twin = new Book("alpha", "Zed", "B", 6);
        assertTrue(Book.BY_TITLE.compare(a, twin) < 0);
    }
}
