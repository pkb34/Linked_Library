import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** Tests for Patron. */
public class PatronTest {
    private Patron ana;
    private Book hobbit;
    private Book dune;

    @Before
    public void setUp() {
        ana = new Patron(" P1 ", " Ana ");
        hobbit = new Book("The Hobbit", "Tolkien", "FIC TOL", 1);
        dune = new Book("Dune", "Herbert", "FIC HER", 2);
    }

    @Test
    public void constructorTrims() {
        assertEquals("P1", ana.getId());
        assertEquals("Ana", ana.getName());
        assertEquals(0, ana.borrowedCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBlankId() {
        new Patron("", "Ana");
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullName() {
        new Patron("P1", null);
    }

    @Test
    public void borrowAddsLoan() {
        ana.borrow(hobbit, 15);
        assertTrue(ana.hasBorrowed(hobbit));
        assertEquals(1, ana.borrowedCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void borrowRejectsNull() {
        ana.borrow(null, 15);
    }

    @Test(expected = IllegalArgumentException.class)
    public void borrowRejectsSameCopyTwice() {
        ana.borrow(hobbit, 15);
        ana.borrow(hobbit, 15);
    }

    @Test
    public void giveBackReturnsTheLoan() {
        ana.borrow(hobbit, 15);
        ana.borrow(dune, 20);
        Loan loan = ana.giveBack(hobbit);
        assertEquals(15, loan.getDueDay());
        assertFalse(ana.hasBorrowed(hobbit));
        assertTrue(ana.hasBorrowed(dune));
    }

    @Test
    public void giveBackSomethingNotBorrowedReturnsNull() {
        assertNull(ana.giveBack(hobbit));   // empty collection
        ana.borrow(dune, 20);
        assertNull(ana.giveBack(hobbit));   // not there
        assertNull(ana.giveBack(null));
        assertEquals(1, ana.borrowedCount());
    }

    @Test
    public void hasBorrowedFalseForNullAndMissing() {
        assertFalse(ana.hasBorrowed(null));
        assertFalse(ana.hasBorrowed(dune));
    }

    @Test
    public void overdueLoansOnlyLateOnes() {
        ana.borrow(hobbit, 10);
        ana.borrow(dune, 30);
        LinkedChain<Loan> late = ana.overdueLoans(20);
        assertEquals(1, late.size());
        assertEquals(hobbit, late.get(0).getBook());
    }

    @Test
    public void overdueLoansEmptyWhenNothingOut() {
        assertTrue(ana.overdueLoans(100).isEmpty());
    }

    @Test
    public void equalsUsesIdNotName() {
        assertEquals(ana, new Patron("P1", "Someone Else"));
        assertEquals(ana.hashCode(), new Patron("P1", "X").hashCode());
        assertNotEquals(ana, new Patron("P2", "Ana"));
    }

    @Test
    public void equalsRejectsNullAndOtherTypes() {
        assertFalse(ana.equals(null));
        assertFalse(ana.equals("P1"));
    }

    @Test
    public void toStringShowsNameAndId() {
        assertEquals("Ana (P1)", ana.toString());
    }
}
