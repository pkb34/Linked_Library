import java.util.Comparator;

/**
 * One physical copy of a book. Two copies of the same title are different
 * Books because equality is based on the unique copy ID.
 */
public class Book {
    /** Arrival order (copy IDs are handed out in order). */
    public static final Comparator<Book> BY_COPY_ID =
        Comparator.comparingInt(Book::getCopyId);
    /** A to Z by title, ignoring case; ties broken by copy ID. */
    public static final Comparator<Book> BY_TITLE =
        Comparator.comparing((Book b) -> b.title.toLowerCase())
            .thenComparing(BY_COPY_ID);
    /** A to Z by author, ignoring case; ties broken by copy ID. */
    public static final Comparator<Book> BY_AUTHOR =
        Comparator.comparing((Book b) -> b.author.toLowerCase())
            .thenComparing(BY_COPY_ID);
    /** A to Z by call number, ignoring case; ties broken by copy ID. */
    public static final Comparator<Book> BY_CALL_NUMBER =
        Comparator.comparing((Book b) -> b.callNumber.toLowerCase())
            .thenComparing(BY_COPY_ID);

    private final String title;
    private final String author;
    private final String callNumber;
    private final int copyId;

    /**
     * Creates a copy.
     *
     * @throws IllegalArgumentException if any text is null/blank or the
     *         copy ID is not positive
     */
    public Book(String title, String author, String callNumber, int copyId) {
        if (isBlank(title) || isBlank(author) || isBlank(callNumber)) {
            throw new IllegalArgumentException(
                "Title, author, and call number are required");
        }
        if (copyId < 1) {
            throw new IllegalArgumentException("Copy ID must be positive");
        }
        this.title = title.trim();
        this.author = author.trim();
        this.callNumber = callNumber.trim();
        this.copyId = copyId;
    }

    /** True if s is null or only whitespace. Shared by every app class. */
    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCallNumber() {
        return callNumber;
    }

    public int getCopyId() {
        return copyId;
    }

    /**
     * True if the title or author contains the query (case-insensitive).
     * A null or blank query matches nothing.
     */
    public boolean matches(String query) {
        if (isBlank(query)) {
            return false;
        }
        String q = query.trim().toLowerCase();
        return title.toLowerCase().contains(q)
            || author.toLowerCase().contains(q);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Book)) {
            return false;
        }
        return copyId == ((Book) other).copyId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(copyId);
    }

    @Override
    public String toString() {
        return "#" + copyId + " " + title + " by " + author
            + " (" + callNumber + ")";
    }
}
