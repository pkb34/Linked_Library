/**
 * One patron waiting for any copy of one title (call number).
 * The sequence number records arrival order, so the waiting list is fair
 * without depending on where the chain places new elements.
 */
public class HoldRequest {
    private final Patron patron;
    private final String callNumber;
    private final int sequence;

    /**
     * @throws IllegalArgumentException if patron is null, the call number
     *         is blank, or the sequence is not positive
     */
    public HoldRequest(Patron patron, String callNumber, int sequence) {
        if (patron == null || Book.isBlank(callNumber)) {
            throw new IllegalArgumentException(
                "Patron and call number are required");
        }
        if (sequence < 1) {
            throw new IllegalArgumentException("Sequence must be positive");
        }
        this.patron = patron;
        this.callNumber = callNumber.trim();
        this.sequence = sequence;
    }

    public Patron getPatron() {
        return patron;
    }

    public String getCallNumber() {
        return callNumber;
    }

    public int getSequence() {
        return sequence;
    }

    /** Same patron waiting for the same title = duplicate hold. */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof HoldRequest)) {
            return false;
        }
        HoldRequest h = (HoldRequest) other;
        return patron.equals(h.patron) && callNumber.equals(h.callNumber);
    }

    @Override
    public int hashCode() {
        return 31 * patron.hashCode() + callNumber.hashCode();
    }

    @Override
    public String toString() {
        return patron + " waiting for " + callNumber;
    }
}
