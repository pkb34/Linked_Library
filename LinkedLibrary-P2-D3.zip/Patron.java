/**
 * One library member and the copies they currently have on loan.
 * Equality is based on patron ID, so two patrons may share a name.
 */
public class Patron {
    private final String patronId;
    private final String name;
    private final LinkedChain<Loan> loans;

    /**
     * @throws IllegalArgumentException if the ID or name is null/blank
     */
    public Patron(String patronId, String name) {
        if (Book.isBlank(patronId) || Book.isBlank(name)) {
            throw new IllegalArgumentException("ID and name are required");
        }
        this.patronId = patronId.trim();
        this.name = name.trim();
        this.loans = new LinkedChain<Loan>();
    }

    public String getId() {
        return patronId;
    }

    public String getName() {
        return name;
    }

    /**
     * Records that this patron now has the copy, due on dueDay.
     *
     * @throws IllegalArgumentException if book is null, the due day is not
     *         positive, or the patron already has this copy
     */
    public void borrow(Book book, int dueDay) {
        Loan loan = new Loan(book, this, dueDay);
        if (loans.contains(loan)) {
            throw new IllegalArgumentException("Already borrowed");
        }
        loans.add(loan);
    }

    /**
     * Ends the loan for that copy.
     *
     * @return the ended loan, or null if this patron did not have the copy
     */
    public Loan giveBack(Book book) {
        Loan loan = findLoan(book);
        if (loan != null) {
            loans.remove(loan);
        }
        return loan;
    }

    /** True if this patron currently has that copy. */
    public boolean hasBorrowed(Book book) {
        return findLoan(book) != null;
    }

    /** Number of copies on loan. */
    public int borrowedCount() {
        return loans.size();
    }

    /** This patron's loans that are late on the given day. */
    public LinkedChain<Loan> overdueLoans(int today) {
        return ChainTools.findAll(loans, l -> l.daysLate(today) > 0);
    }

    private Loan findLoan(Book book) {
        if (book == null) {
            return null;
        }
        return ChainTools.findFirst(loans, l -> l.getBook().equals(book));
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Patron)) {
            return false;
        }
        return patronId.equals(((Patron) other).patronId);
    }

    @Override
    public int hashCode() {
        return patronId.hashCode();
    }

    @Override
    public String toString() {
        return name + " (" + patronId + ")";
    }
}
