import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for Library. Each public method has a normal case and a bad-input
 * case; the bad-input cases come from our scope document.
 */
public class LibraryTest {
    private Library lib;

    /** Two patrons and two copies of The Hobbit (#1, #2) plus Dune (#3). */
    @Before
    public void setUp() {
        lib = new Library();
        lib.addPatron("P1", "Ana");
        lib.addPatron("P2", "Bo");
        lib.addBook("The Hobbit", "Tolkien", "FIC TOL");
        lib.addBook("The Hobbit", "Tolkien", "FIC TOL");
        lib.addBook("Dune", "Herbert", "FIC HER");
    }

    // ----- addBook -----

    @Test
    public void addBookShelvesNewCopy() {
        assertEquals(Outcome.SUCCESS,
            lib.addBook("Anathem", "Stephenson", "SF STE"));
        assertEquals(4, lib.catalogSize());
        assertTrue(lib.isOnShelf(4));
    }

    @Test
    public void addBookRejectsBlankAndNull() {
        assertEquals(Outcome.INVALID_INPUT, lib.addBook("  ", "A", "B"));
        assertEquals(Outcome.INVALID_INPUT, lib.addBook("T", null, "B"));
        assertEquals(3, lib.catalogSize());
    }

    @Test
    public void addBookGivesCopyToWaitingPatron() {
        lib.checkOut("P1", "FIC HER");
        lib.placeHold("P2", "FIC HER");
        assertEquals(Outcome.ASSIGNED_TO_HOLD,
            lib.addBook("Dune", "Herbert", "FIC HER"));
        assertTrue(lib.hasBorrowed("P2", 4));
        assertEquals(0, lib.holdCount("FIC HER"));
    }

    // ----- removeBook -----

    @Test
    public void removeOneOfManyIdenticalCopies() {
        assertEquals(Outcome.SUCCESS, lib.removeBook(1));
        assertEquals(2, lib.catalogSize());
        assertTrue(lib.isOnShelf(2));   // the other Hobbit copy stays
    }

    @Test
    public void removeBookNotThere() {
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.removeBook(99));
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.removeBook(-1));
        assertEquals(3, lib.catalogSize());
    }

    @Test
    public void removeCheckedOutBookRefused() {
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.HAS_DEPENDENTS, lib.removeBook(3));
        assertEquals(3, lib.catalogSize());
    }

    // ----- addPatron / removePatron -----

    @Test
    public void addPatronAllowsSameNameDifferentId() {
        assertEquals(Outcome.SUCCESS, lib.addPatron("P3", "Ana"));
        assertEquals(3, lib.patronCount());
    }

    @Test
    public void addPatronRejectsDuplicateIdAndBlank() {
        assertEquals(Outcome.DUPLICATE_ID, lib.addPatron(" P1 ", "Other"));
        assertEquals(Outcome.INVALID_INPUT, lib.addPatron("", "X"));
        assertEquals(Outcome.INVALID_INPUT, lib.addPatron("P9", null));
        assertEquals(2, lib.patronCount());
    }

    @Test
    public void removePatronWithNothingOut() {
        assertEquals(Outcome.SUCCESS, lib.removePatron("P2"));
        assertEquals(1, lib.patronCount());
    }

    @Test
    public void removePatronNotThereOrWithDependents() {
        assertEquals(Outcome.PATRON_NOT_FOUND, lib.removePatron("P9"));
        assertEquals(Outcome.PATRON_NOT_FOUND, lib.removePatron(null));
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.HAS_DEPENDENTS, lib.removePatron("P1"));
        lib.placeHold("P2", "FIC HER");
        assertEquals(Outcome.HAS_DEPENDENTS, lib.removePatron("P2"));
        assertEquals(2, lib.patronCount());
    }

    @Test
    public void removeFromEmptyLibrary() {
        Library empty = new Library();
        assertEquals(Outcome.PATRON_NOT_FOUND, empty.removePatron("P1"));
        assertEquals(Outcome.BOOK_NOT_FOUND, empty.removeBook(1));
    }

    // ----- checkOut -----

    @Test
    public void checkOutMovesCopyToPatron() {
        assertEquals(Outcome.SUCCESS, lib.checkOut("P1", "FIC HER"));
        assertFalse(lib.isOnShelf(3));
        assertTrue(lib.hasBorrowed("P1", 3));
    }

    @Test
    public void checkOutBadInputChangesNothing() {
        assertEquals(Outcome.PATRON_NOT_FOUND, lib.checkOut("P9", "FIC HER"));
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.checkOut("P1", "NOPE"));
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.checkOut("P1", null));
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.NONE_AVAILABLE, lib.checkOut("P2", "FIC HER"));
        assertEquals(0, lib.borrowedCount("P2"));
    }

    // ----- returnBook -----

    @Test
    public void returnBookGoesBackToShelf() {
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.SUCCESS, lib.returnBook("P1", 3));
        assertTrue(lib.isOnShelf(3));
    }

    @Test
    public void returnBookAutoAssignsToEarliestHold() {
        lib.addPatron("P3", "Cy");
        lib.checkOut("P1", "FIC HER");
        lib.placeHold("P2", "FIC HER");
        lib.placeHold("P3", "FIC HER");
        assertEquals(Outcome.ASSIGNED_TO_HOLD, lib.returnBook("P1", 3));
        assertTrue(lib.hasBorrowed("P2", 3));   // first in line
        assertEquals(1, lib.holdCount("FIC HER"));
    }

    @Test
    public void returnBookNeverBorrowedMovesNothing() {
        assertEquals(Outcome.NOT_BORROWED, lib.returnBook("P1", 3));
        assertEquals(Outcome.PATRON_NOT_FOUND, lib.returnBook("P9", 3));
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.returnBook("P1", 99));
        assertTrue(lib.isOnShelf(3));
    }

    // ----- placeHold -----

    @Test
    public void placeHoldWhenAllCopiesOut() {
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.SUCCESS, lib.placeHold("P2", "FIC HER"));
        assertEquals(1, lib.holdCount("FIC HER"));
    }

    @Test
    public void placeHoldBadInput() {
        assertEquals(Outcome.BOOK_AVAILABLE, lib.placeHold("P2", "FIC HER"));
        assertEquals(Outcome.PATRON_NOT_FOUND, lib.placeHold("P9", "FIC HER"));
        assertEquals(Outcome.BOOK_NOT_FOUND, lib.placeHold("P2", " "));
        lib.checkOut("P1", "FIC HER");
        lib.placeHold("P2", "FIC HER");
        assertEquals(Outcome.ALREADY_ON_HOLD, lib.placeHold("P2", "FIC HER"));
        assertEquals(1, lib.holdCount("FIC HER"));
    }

    // ----- undo -----

    @Test
    public void undoCheckout() {
        lib.checkOut("P1", "FIC HER");
        assertEquals(Outcome.SUCCESS, lib.undo());
        assertTrue(lib.isOnShelf(3));
        assertEquals(0, lib.borrowedCount("P1"));
    }

    @Test
    public void undoReturnGivesBookBack() {
        lib.checkOut("P1", "FIC HER");
        lib.returnBook("P1", 3);
        assertEquals(Outcome.SUCCESS, lib.undo());
        assertTrue(lib.hasBorrowed("P1", 3));
        assertFalse(lib.isOnShelf(3));
    }

    @Test
    public void undoAutoAssignRestoresHoldAtFront() {
        lib.addPatron("P3", "Cy");
        lib.checkOut("P1", "FIC HER");
        lib.placeHold("P2", "FIC HER");
        lib.placeHold("P3", "FIC HER");
        lib.returnBook("P1", 3);              // goes to P2
        assertEquals(Outcome.SUCCESS, lib.undo());
        assertTrue(lib.hasBorrowed("P1", 3));
        assertEquals(2, lib.holdCount("FIC HER"));
        lib.returnBook("P1", 3);              // P2 still first in line
        assertTrue(lib.hasBorrowed("P2", 3));
    }

    @Test
    public void undoAddAndRemoveBook() {
        lib.removeBook(3);
        assertEquals(Outcome.SUCCESS, lib.undo());
        assertTrue(lib.isOnShelf(3));
        lib.addBook("Anathem", "Stephenson", "SF STE");
        assertEquals(Outcome.SUCCESS, lib.undo());
        assertEquals(3, lib.catalogSize());
    }

    @Test
    public void undoWithEmptyHistory() {
        Library fresh = new Library();
        assertEquals(Outcome.NOTHING_TO_UNDO, fresh.undo());
    }

    @Test
    public void undoNoLongerValidChangesNothing() {
        lib.checkOut("P2", "FIC HER");
        lib.returnBook("P2", 3);
        lib.removePatron("P2");               // not undoable
        assertEquals(Outcome.UNDO_INVALID, lib.undo());
        assertTrue(lib.isOnShelf(3));
        assertEquals(1, lib.patronCount());
    }

    @Test
    public void historyCappedAtLimit() {
        for (int i = 0; i < 15; i++) {
            lib.checkOut("P1", "FIC HER");
            lib.returnBook("P1", 3);
        }
        assertEquals(Library.HISTORY_LIMIT, lib.historySize());
    }

    // ----- search -----

    @Test
    public void searchFindsAllMatchingCopies() {
        LinkedChain<Book> found = lib.search("hob");
        assertEquals(2, found.size());
    }

    @Test
    public void searchBlankOrMissingIsEmpty() {
        assertTrue(lib.search("zzz").isEmpty());
        assertTrue(lib.search("   ").isEmpty());
        assertTrue(lib.search(null).isEmpty());
        assertTrue(new Library().search("hob").isEmpty());
    }

    // ----- sortedShelf -----

    @Test
    public void sortedShelfByTitleLeavesShelfAlone() {
        Book[] byTitle = lib.sortedShelf(Book.BY_TITLE);
        assertEquals("Dune", byTitle[0].getTitle());
        assertEquals(3, byTitle.length);
        Book[] arrival = lib.sortedShelf(Book.BY_COPY_ID);
        assertEquals(1, arrival[0].getCopyId());
        assertEquals(3, lib.shelfSize());
    }

    @Test
    public void sortedShelfEmptyAndNullComparator() {
        assertEquals(0, new Library().sortedShelf(Book.BY_TITLE).length);
        try {
            lib.sortedShelf(null);
            fail("expected IllegalArgumentException");
        }
        catch (IllegalArgumentException e) {
            assertEquals(3, lib.shelfSize());
        }
    }

    // ----- due dates (stretch goal) -----

    @Test
    public void advanceDaysMovesClock() {
        assertEquals(1, lib.getToday());
        assertEquals(Outcome.SUCCESS, lib.advanceDays(5));
        assertEquals(6, lib.getToday());
    }

    @Test
    public void advanceDaysRejectsZeroAndNegative() {
        assertEquals(Outcome.INVALID_INPUT, lib.advanceDays(0));
        assertEquals(Outcome.INVALID_INPUT, lib.advanceDays(-3));
        assertEquals(1, lib.getToday());
    }

    @Test
    public void overdueLoansMostLateFirst() {
        lib.checkOut("P1", "FIC TOL");          // due day 15
        lib.advanceDays(5);
        lib.checkOut("P2", "FIC HER");          // due day 20
        lib.advanceDays(20);                    // today = 26
        Loan[] late = lib.overdueLoans();
        assertEquals(2, late.length);
        assertEquals(11, late[0].daysLate(lib.getToday()));
        assertEquals(6, late[1].daysLate(lib.getToday()));
    }

    @Test
    public void overdueLoansEmptyWhenNothingLate() {
        assertEquals(0, lib.overdueLoans().length);
        lib.checkOut("P1", "FIC HER");
        lib.advanceDays(Library.LOAN_DAYS);     // due today, not late
        assertEquals(0, lib.overdueLoans().length);
    }

    // ----- queries -----

    @Test
    public void queriesOnKnownItems() {
        assertEquals(3, lib.catalogSize());
        assertEquals(3, lib.shelfSize());
        assertEquals(2, lib.patronCount());
        assertEquals(3, lib.historySize());     // three ADD_BOOKs
        assertEquals(0, lib.borrowedCount("P1"));
        assertTrue(lib.isOnShelf(1));
    }

    @Test
    public void queriesOnUnknownItems() {
        assertEquals(-1, lib.borrowedCount("P9"));
        assertEquals(-1, lib.borrowedCount(null));
        assertFalse(lib.isOnShelf(42));
        assertFalse(lib.hasBorrowed("P9", 1));
        assertFalse(lib.hasBorrowed("P1", 42));
        assertEquals(0, lib.holdCount(null));
        assertEquals(0, lib.holdCount("NOPE"));
    }

    // ----- invariant stress test -----

    @Test
    public void rapidCheckoutReturnUndoKeepsEveryCopyInOnePlace() {
        String[] ids = {"P1", "P2"};
        for (int i = 0; i < 200; i++) {
            String id = ids[i % 2];
            switch (i % 5) {
                case 0: lib.checkOut(id, "FIC TOL"); break;
                case 1: lib.returnBook(id, 1 + i % 3); break;
                case 2: lib.placeHold(id, "FIC TOL"); break;
                case 3: lib.undo(); break;
                default: lib.checkOut(id, "FIC HER"); break;
            }
            int placed = lib.shelfSize() + lib.borrowedCount("P1")
                + lib.borrowedCount("P2");
            assertEquals("step " + i, lib.catalogSize(), placed);
        }
    }
}
