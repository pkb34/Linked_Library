import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** Tests for HoldRequest. */
public class HoldRequestTest {
    private Patron ana;
    private HoldRequest hold;

    @Before
    public void setUp() {
        ana = new Patron("P1", "Ana");
        hold = new HoldRequest(ana, " FIC TOL ", 3);
    }

    @Test
    public void gettersReturnTrimmedValues() {
        assertSame(ana, hold.getPatron());
        assertEquals("FIC TOL", hold.getCallNumber());
        assertEquals(3, hold.getSequence());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullPatron() {
        new HoldRequest(null, "FIC TOL", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBlankCallNumber() {
        new HoldRequest(ana, "  ", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBadSequence() {
        new HoldRequest(ana, "FIC TOL", 0);
    }

    @Test
    public void samePatronSameTitleIsDuplicate() {
        HoldRequest later = new HoldRequest(new Patron("P1", "Ana"),
            "FIC TOL", 9);
        assertEquals(hold, later);
        assertEquals(hold.hashCode(), later.hashCode());
    }

    @Test
    public void differentPatronOrTitleIsNotDuplicate() {
        assertNotEquals(hold, new HoldRequest(new Patron("P2", "Bo"),
            "FIC TOL", 4));
        assertNotEquals(hold, new HoldRequest(ana, "FIC HER", 4));
        assertFalse(hold.equals(null));
        assertFalse(hold.equals("FIC TOL"));
    }

    @Test
    public void toStringShowsWhoAndWhat() {
        assertEquals("Ana (P1) waiting for FIC TOL", hold.toString());
    }
}
