import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** Tests for Loan. */
public class LoanTest {
    private Book book;
    private Patron ana;
    private Loan loan;

    @Before
    public void setUp() {
        book = new Book("The Hobbit", "Tolkien", "FIC TOL", 1);
        ana = new Patron("P1", "Ana");
        loan = new Loan(book, ana, 15);
    }

    @Test
    public void gettersReturnConstructorValues() {
        assertSame(book, loan.getBook());
        assertSame(ana, loan.getPatron());
        assertEquals(15, loan.getDueDay());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullBook() {
        new Loan(null, ana, 15);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullPatron() {
        new Loan(book, null, 15);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBadDueDay() {
        new Loan(book, ana, 0);
    }

    @Test
    public void daysLateCountsDaysPastDue() {
        assertEquals(5, loan.daysLate(20));
    }

    @Test
    public void daysLateIsZeroOnOrBeforeDueDay() {
        assertEquals(0, loan.daysLate(15));
        assertEquals(0, loan.daysLate(-3));
    }

    @Test
    public void equalsUsesBook() {
        Loan sameCopy = new Loan(book, new Patron("P2", "Bo"), 30);
        assertEquals(loan, sameCopy);
        assertEquals(loan.hashCode(), sameCopy.hashCode());
    }

    @Test
    public void equalsRejectsOtherCopiesAndTypes() {
        Book other = new Book("The Hobbit", "Tolkien", "FIC TOL", 2);
        assertNotEquals(loan, new Loan(other, ana, 15));
        assertFalse(loan.equals(null));
        assertFalse(loan.equals(book));
    }

    @Test
    public void toStringShowsBookPatronAndDueDay() {
        assertEquals("#1 The Hobbit by Tolkien (FIC TOL) - Ana (P1), due day 15",
            loan.toString());
    }
}
