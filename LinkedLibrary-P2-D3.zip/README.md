# Linked Library: P2 Prototype

A checkout-desk program for a small branch library. The librarian adds books and patrons, checks copies out and in, keeps waiting lists (holds) that auto-assign on return, undoes mistakes, searches, sorts the shelf, and sees an overdue report.

**One generic class, five element types.** The provided `LinkedChain<T>` (unchanged) stores `Book`, `Patron`, `HoldRequest`, `Loan`, and `Action`. The tests also run our generic helpers on `LinkedChain<String>`.

## How to compile and run

All `.java` files are in one folder (default package). The tests use **JUnit 4**.

**Eclipse:** import the folder as a Java project. Then go to Build Path → Add Libraries → JUnit → JUnit 4.
- Program: run `LibraryApp`.
- Tests: right-click the project → Run As → JUnit Test.

**Command line** (`junit-4.13.2.jar` and `hamcrest-core-1.3.jar` in the same folder; on Windows use `;` instead of `:`):

```
javac -cp .:junit-4.13.2.jar:hamcrest-core-1.3.jar *.java
java LibraryApp
java -cp .:junit-4.13.2.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore BookTest LoanTest PatronTest HoldRequestTest ActionTest ChainToolsTest LibraryTest LibraryMenuTest
```

Current result: **112 tests, all passing.**

**Try the MVP path:** 2 (add patrons P1, P2) → 1 (add a book) → 3 (P1 checks it out) → 3 (P2 tries, answers `y` to place a hold) → 4 (P1 returns it, so it goes to P2) → 9 (undo) → 8 (sorted shelf) → 12 (advance 20 days) → 13 (overdue report).

## Class design

| Class | One job | LinkedChain use |
|---|---|---|
| `LinkedChain<T>` (provided, unchanged) | Generic storage only | |
| `Book` | One physical copy. `equals` uses copy ID. Has 4 static comparators | |
| `Patron` | One member and their loans. `equals` uses patron ID | `LinkedChain<Loan>` |
| `Loan` | One checked-out copy: book, patron, due day | |
| `HoldRequest` | One patron waiting for one title, with an arrival number | |
| `Action` / `ActionType` | Immutable record of one undoable event | |
| `Outcome` | Result codes and the message the user sees | |
| `ChainTools` | Generic `findFirst`, `findAll`, `snapshot`, `sortedSnapshot` for any `LinkedChain<T>` | Public API only |
| `Library` | All rules: books, patrons, checkout, return, holds, undo, search, sort, due dates | `LinkedChain<Book>` ×2, `<Patron>`, `<HoldRequest>`, `<Action>` |
| `LibraryMenu` | Console I/O. Validates raw input and prints results | |
| `LibraryApp` | `main` | |

`Library` never prints, `LibraryMenu` never changes state, and `LinkedChain` holds no library logic. **Invariant:** every copy in the catalog is in exactly one place, either on the shelf or on one patron's loan list. `LibraryTest.rapidCheckoutReturnUndoKeepsEveryCopyInOnePlace` checks this after each of 200 mixed operations.

**LinkedChain methods the app calls:** `add`, `addToEnd`, `remove()`, `remove(T)`, `get`, `contains`, `size`, `isEmpty`, `toArray(T[])`.

## Big-O: spec estimate vs. what we built

*n* = elements in the chain(s) the method walks. Every search takes **one** `toArray` snapshot (O(n)). Calling `get(i)` in a loop would be O(n²), because each `get` walks from the head.

| Method | Spec | Built | Why it differs |
|---|---|---|---|
| `Library.addBook` | O(1) | **O(n)** | Now checks the hold list so a new copy can go straight to a waiting patron |
| `Library.removeBook` / `addPatron` / `removePatron` | O(n) | O(n) | |
| `Library.checkOut` / `returnBook` / `placeHold` | O(n) | O(n) | |
| `Library.undo` | O(n) | O(n) | `remove()` is O(1); the validity checks are O(n) |
| `Library.search` / `holdCount` / `isOnShelf` / `hasBorrowed` / `borrowedCount` | O(n) | O(n) | |
| `Library.sortedShelf` | O(n²) | O(n²) | Insertion sort on a copy |
| `Library.overdueLoans` (stretch) | — | O(n²) | Collect late loans O(n), then insertion sort |
| `Library.advanceDays`, `getToday`, size queries | O(1) | O(1) | |
| `Patron.borrow` | O(1) | **O(n)** | Checks that the copy isn't already on loan before `add` |
| `Patron.giveBack` / `hasBorrowed` / `overdueLoans` | O(n) | O(n) | |
| `ChainTools.findFirst` / `findAll` / `snapshot` | O(n) | O(n) | |
| `ChainTools.sortedSnapshot` | O(n²) | O(n²) | |
| `LibraryMenu.readInt` / `readText` / `readYesNo` | O(1) per try | O(1) per try | |

## Bad input: where each case is caught

| Bad input (from our scope) | Caught in | Response (as in our spec) | Test |
|---|---|---|---|
| Remove from an empty collection | `Library.removeBook` / `removePatron` / `undo`, `Patron.giveBack` | `BOOK_NOT_FOUND` / `PATRON_NOT_FOUND` / `NOTHING_TO_UNDO` / `null`, nothing changes | `removeFromEmptyLibrary`, `undoWithEmptyHistory`, `giveBackSomethingNotBorrowedReturnsNull` |
| Remove something that isn't there | Same methods | Same outcomes, nothing changes | `removeBookNotThere`, `returnBookNeverBorrowedMovesNothing` |
| `null` passed in | `Library` (`isBlank` guards), element constructors as backstop | `INVALID_INPUT` / not found; constructors throw `IllegalArgumentException`. `null` never reaches the chain | `addBookRejectsBlankAndNull`, `constructorRejects…` |
| Index out of range | No index ever comes from the user; copy numbers are looked up by ID | `BOOK_NOT_FOUND` for a bad copy # | `removeBookNotThere` (#99, #-1) |
| Blank title / author / name | `LibraryMenu.readText` (re-prompt); `Library` returns `INVALID_INPUT` if called directly | Re-prompt | `readTextRepromptsOnBlankAndTooLong` |
| Non-numeric or out-of-range menu choice | `LibraryMenu.readInt` | Re-prompt | `readIntRepromptsOnTextAndOutOfRange`, `runSurvivesBadInput` |
| Check out a book not on the shelf | `Library.checkOut` → menu offers a hold | `NONE_AVAILABLE`, then "Place a hold instead?" | `runMvpPath` |
| Patron doesn't exist | `Library` (every patron method) | `PATRON_NOT_FOUND` | `checkOutBadInputChangesNothing` |
| Return a book never borrowed | `Library.returnBook` | `NOT_BORROWED`, nothing moves | `returnBookNeverBorrowedMovesNothing` |
| Hold on an available book | `Library.placeHold` | `BOOK_AVAILABLE` | `placeHoldBadInput` |
| Duplicate hold | `Library.placeHold` (`holds.contains`) | `ALREADY_ON_HOLD` | `placeHoldBadInput` |
| Undo with empty history | `Library.undo` | `NOTHING_TO_UNDO` | `undoWithEmptyHistory` |
| Very long / special-character text | `LibraryMenu.readText` | Over 100 chars re-prompts; quotes, commas, accents stored as-is | `readTextKeepsSpecialCharacters`, `specialCharactersStoredAsIs` |
| Remove a patron/book with holds or checkouts | `Library.removePatron` / `removeBook` | `HAS_DEPENDENTS`, refused (not cascaded) | `removePatronNotThereOrWithDependents`, `removeCheckedOutBookRefused` |
| Undo an action that's no longer valid | `Library.undo` (checks before changing) | `UNDO_INVALID`, state unchanged | `undoNoLongerValidChangesNothing` |
| Rapid repeated checkout/return | `Library` (each method all-or-nothing) | Invariant holds | `rapidCheckoutReturnUndoKeepsEveryCopyInOnePlace` |
| Many identical copies, remove one | `LinkedChain.remove(T)` + `Book.equals` on copy ID | Exactly one removed | `removeOneOfManyIdenticalCopies` |
| Input ends unexpectedly (Ctrl-D) | `LibraryMenu.run` | Exits with "Goodbye." instead of crashing | `runEndsCleanlyWhenInputRunsOut` |

## Reflection

### What changed from our specification

| Spec said | We built | Why | Origin |
|---|---|---|---|
| Add `addFirst`, `addLast`, `removeFirst`, `peekFirst`, `filter`, `sortedCopy`, and a tail reference to `LinkedChain` | The provided chain **unchanged**. Search and sort live in a new generic `ChainTools` class | The provided class already had `add` (front), `addToEnd`, `remove()`, `get`, and `toArray`. Keeping helpers outside the chain keeps "the chain owns storage only" true | Group, after reading the provided class |
| `Patron` holds `LinkedChain<Book>` | `Patron` holds `LinkedChain<Loan>` (new `Loan` class) | Our due-date stretch goal needs a due day per checkout | Group decision to start the stretch goal |
| Hold order = chain order | Holds are added with `addToEnd`, and each `HoldRequest` also has a sequence number. The lowest number is served first | Undo has to put a hold back in its original place, which a position alone can't do | GenAI suggestion, checked by group |
| Auto-assign on return logged as RETURN + CHECKOUT | One `Action` with a `filledHold` field | One undo now reverses the return and the auto-assign together, with no half-undone state | Our own reflection while testing undo |
| `sortedShelf` returns a `LinkedChain<Book>` | Returns a `Book[]` copy | A sorted *view* shouldn't look like stored order; the shelf is never reordered | Group |
| `readText(prompt, maxLen)` | `readText(prompt)` with constant `MAX_TEXT = 100` | Every field had the same limit | Own reflection |
| Menu could crash at end of input | `run()` exits cleanly; `readX` throws `IllegalStateException` | Found while writing scripted menu tests | Testing |
| Remove book refused if "last copy of a held title" | Refused only if checked out | A shelved copy can never have a waiting hold, because it would already be auto-assigned | Own reflection |
| Test plan for `LinkedChain` methods | Tests for every public **app** method (the chain is provided) | This deliverable grades the app's use of the chain | Rubric |

### What changed in the LinkedChain

Nothing. We used `LinkedChain.java` exactly as provided. `add` + `remove()` act as a stack for undo history (front = newest). `addToEnd` keeps holds in arrival order. `toArray(T[])` gives a one-pass O(n) snapshot for searches. The only place we call `get(i)` is to drop the oldest action when history passes 10.

### What happened to our unknowns

| Unknown from scope | Status |
|---|---|
| Keeping hold queues consistent when a patron or book is removed | **Solved.** Removal is refused while there are loans or holds, so no hold can point to a missing patron. Tested in `removePatronNotThereOrWithDependents` |
| Testing reuse across four types | **Solved.** Five types go through one `LinkedChain`, and `ChainToolsTest` runs the same generic helpers on `String` and `Book` |
| Undo, our biggest MVP risk | **Mostly solved.** Checkout, return, add, and remove are undoable, including auto-assigned holds. Invalid undos are detected before anything changes. **Still open:** undoing `placeHold`, `addPatron`, and `removePatron` |

### What doesn't work yet

- `placeHold`, `addPatron`, and `removePatron` can't be undone.
- A patron can't cancel a hold.
- Only the shelf can be sorted. The scope said "sort a copy of any list," so search results and a patron's loans are still unsorted.
- Due dates use a simulated day counter ("advance days"), not real calendar dates.
- No data is saved between runs.
- All 112 tests pass. No known failing tests.

## Next Steps

### Remaining MVP work, in order

| # | Item | Owner |
|---|---|---|
| 1 | Sorted view for search results and a patron's loans (reuse `ChainTools.sortedSnapshot`) | [Member A] |
| 2 | Cancel a hold (`Library.cancelHold`) and a menu option | [Member C] |
| 3 | Undo for `placeHold` and `cancelHold` (new `ActionType`s) | [Member C] |
| 4 | Menu options for items 1–3 | [Member D] |
| 5 | Final pass: re-run every test, update this README, and rehearse the oral exam | Everyone |

### Stretch goals

| Stretch goal (from scope) | Decision |
|---|---|
| Due dates and overdue report | **Done in this prototype** (`advanceDays`, `overdueLoans`, menu options 12–13) |
| `Iterator<T>` on `LinkedChain` (added in spec) | **Committed.** Lets the app use for-each instead of `toArray` snapshots |
| Patron login with librarian/patron roles | **Dropped.** It would double the menu and test surface for little gain in the remaining time |

### New tests we will need

- `sortedSearch` / `sortedLoans`: normal sort by each field; empty result; null comparator throws
- `cancelHold`: cancel an existing hold; cancel a hold that isn't there; unknown patron; blank call number
- `undo` after `placeHold` and after `cancelHold`, restoring the original queue position; undo a cancel when the title was assigned since → `UNDO_INVALID`
- `LinkedChain.iterator()`: for-each over an empty chain; `next()` past the end throws `NoSuchElementException`
- `LibraryMenu.run` script covering every new menu option and its bad input

## Attribution

| File | Team member(s) | How |
|---|---|---|
| `LinkedChain.java` | CS 2114 staff | Provided; used unchanged |
| `Book.java` | [Member B] | Wrote with GenAI assistance; reviewed by [Member A] |
| `Loan.java` | [Member B] | Wrote with GenAI assistance; reviewed |
| `Patron.java` | [Member B] | Wrote with GenAI assistance; revised for loans |
| `HoldRequest.java` | [Member B] | Wrote with GenAI assistance; reviewed |
| `Action.java`, `ActionType.java` | [Member C] | Wrote with GenAI assistance |
| `Outcome.java` | [Member C] | Wrote |
| `ChainTools.java` | [Member A] | Wrote with GenAI assistance; Big-O checked by hand |
| `Library.java` | [Member C] | Wrote with GenAI assistance; revised undo design with group |
| `LibraryMenu.java` | [Member D] | Wrote with GenAI assistance; tested by hand |
| `LibraryApp.java` | [Member D] | Wrote |
| `BookTest.java`, `LoanTest.java` | [Member A] | GenAI-suggested edge cases; each kept test reviewed |
| `PatronTest.java`, `HoldRequestTest.java` | [Member B] | GenAI-suggested edge cases; reviewed |
| `ActionTest.java` | [Member C] | Wrote |
| `ChainToolsTest.java` | [Member A] | Wrote |
| `LibraryTest.java` | [Member C] & [Member D] | Wrote from the spec's test plan; stress test GenAI-suggested |
| `LibraryMenuTest.java` | [Member D] | Wrote with GenAI assistance |

**GenAI use:** We used Claude to draft the app classes from our specification after we gave it the provided `LinkedChain.java`. We also used it to suggest edge-case tests (empty collections, removing something that isn't there, input the app should reject) and to review our Big-O estimates. Every suggestion was read by the class owner. We kept only tests that check behavior we named in our scope, and we made the design calls ourselves: sequence numbers for holds, one undo action for return + auto-assign, and leaving `LinkedChain` unchanged. Each owner can explain their class line by line.
