import static org.junit.Assert.*;

import org.junit.Test;

/** Tests for Action, ActionType, and Outcome. */
public class ActionTest {
    private final Book book = new Book("Dune", "Herbert", "FIC HER", 2);
    private final Patron bo = new Patron("P2", "Bo");

    @Test
    public void gettersReturnConstructorValues() {
        HoldRequest hold = new HoldRequest(bo, "FIC HER", 1);
        Action a = new Action(4, ActionType.RETURN, book, bo, 15, hold);
        assertEquals(4, a.getSequence());
        assertEquals(ActionType.RETURN, a.getType());
        assertSame(book, a.getBook());
        assertSame(bo, a.getPatron());
        assertEquals(15, a.getDueDay());
        assertSame(hold, a.getFilledHold());
    }

    @Test
    public void addBookActionHasNoPatronOrHold() {
        Action a = new Action(1, ActionType.ADD_BOOK, book, null, 0, null);
        assertNull(a.getPatron());
        assertNull(a.getFilledHold());
        assertEquals("ADD_BOOK #2 Dune by Herbert (FIC HER)", a.toString());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullType() {
        new Action(1, null, book, bo, 0, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsNullBook() {
        new Action(1, ActionType.CHECKOUT, null, bo, 0, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsBadSequence() {
        new Action(0, ActionType.CHECKOUT, book, bo, 0, null);
    }

    @Test
    public void toStringIncludesPatron() {
        Action a = new Action(1, ActionType.CHECKOUT, book, bo, 15, null);
        assertEquals("CHECKOUT #2 Dune by Herbert (FIC HER) / Bo (P2)",
            a.toString());
    }

    @Test
    public void actionTypeHasFourKinds() {
        assertEquals(4, ActionType.values().length);
        assertEquals(ActionType.CHECKOUT, ActionType.valueOf("CHECKOUT"));
    }

    @Test
    public void everyOutcomeHasAMessage() {
        for (Outcome o : Outcome.values()) {
            assertFalse(Book.isBlank(o.getMessage()));
        }
        assertEquals("Nothing to undo.", Outcome.NOTHING_TO_UNDO.getMessage());
    }

    @Test(expected = IllegalArgumentException.class)
    public void outcomeValueOfRejectsUnknownName() {
        Outcome.valueOf("NOT_A_REAL_OUTCOME");
    }
}
